from django.views.generic import ListView, CreateView, UpdateView
from .models import App

class AppListView(ListView):
    model = App
    template_name = 'admin/app_list.html'

class AppCreateView(CreateView):
    model = App
    template_name = 'admin/app_form.html'
    fields = ['name', 'link', 'category', 'subcategory', 'points']

class AppUpdateView(UpdateView):
    model = App
    template_name = 'admin/app_form.html'
    fields = ['name', 'link', 'category', 'subcategory', 'points']
