from rest_framework import serializers
from .models import App, UserProfile, Task

class AppSerializer(serializers.ModelSerializer):
    class Meta:
        model = App
        fields = '_all_'

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = '_all_'

class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '_all_'