from django.db import models
from django.contrib.auth.models import User

class App(models.Model):
    name = models.CharField(max_length=100)
    link = models.URLField()
    category = models.CharField(max_length=50)
    subcategory = models.CharField(max_length=50)
    points = models.IntegerField()

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    points_earned = models.IntegerField(default=0)

class Task(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    app = models.ForeignKey(App, on_delete=models.CASCADE)
    completed = models.BooleanField(default=False)
    screenshot = models.ImageField(upload_to='screenshots/', blank=True, null=True)